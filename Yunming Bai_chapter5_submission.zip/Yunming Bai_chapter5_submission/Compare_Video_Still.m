%load data
load('distortion_stillImage.mat')
load('distortion_video.mat')
load('rate_stillImageCodec.mat')
load('rate_video.mat')


plot(Rate_stillImage,distortion_stillImage,'b');
hold on;
plot(Rate_video,distortion_video,'r');

legend('Still-Imgae-Codec','Video-Codec');
xlabel('Rate');
ylabel('PSNR');
